package com.flutter.flutter_trabajo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

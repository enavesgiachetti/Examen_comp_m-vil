class Proveedor {
  final String id;
  final String nombre;
  final String descripcion;
  final String locacion;

  Proveedor({
    required this.id,
    required this.nombre,
    required this.descripcion,
    required this.locacion,
  });
}
